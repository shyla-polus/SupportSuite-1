package com.example.polusServiceRequest.constants;

public class SRTicketStatusConstants {

	  public static final Long IN_PROGRESS = 1L;
	    public static final Long ASSIGNED = 2L;
	    public static final Long APPROVED = 3L;
	    public static final Long REJECTED = 4L;
}
