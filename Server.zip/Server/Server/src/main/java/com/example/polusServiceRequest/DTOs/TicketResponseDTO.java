package com.example.polusServiceRequest.DTOs;

import java.sql.Timestamp;
import java.util.List;

import lombok.Data;


public class TicketResponseDTO {

	private Long ticketId;
	private SRTicketCategoryDTO category;
	private String requestDescription;
	private StatusDTO statusDescription;
	private PersonDTO assignedTo;
	private Timestamp createTimestamp;
	private Timestamp updateTimestamp;
	private List<CommentDetailsDTO> comment;
	
	public Long getTicketId() {
		return ticketId;
	}
	public void setTicketId(Long ticketId) {
		this.ticketId = ticketId;
	}
	public SRTicketCategoryDTO getCategory() {
		return category;
	}
	public void setCategory(SRTicketCategoryDTO category) {
		this.category = category;
	}
	public String getRequestDescription() {
		return requestDescription;
	}
	public void setRequestDescription(String requestDescription) {
		this.requestDescription = requestDescription;
	}
	public StatusDTO getStatusDescription() {
		return statusDescription;
	}
	public void setStatusDescription(StatusDTO statusDescription) {
		this.statusDescription = statusDescription;
	}
	public PersonDTO getAssignedTo() {
		return assignedTo;
	}
	public void setAssignedTo(PersonDTO assignedTo) {
		this.assignedTo = assignedTo;
	}
	public Timestamp getCreateTimestamp() {
		return createTimestamp;
	}
	public void setCreateTimestamp(Timestamp createTimestamp) {
		this.createTimestamp = createTimestamp;
	}
	public Timestamp getUpdateTimestamp() {
		return updateTimestamp;
	}
	public void setUpdateTimestamp(Timestamp updateTimestamp) {
		this.updateTimestamp = updateTimestamp;
	}
	public List<CommentDetailsDTO> getComment() {
		return comment;
	}
	public void setComment(List<CommentDetailsDTO> comment) {
		this.comment = comment;
	}
	
	
}