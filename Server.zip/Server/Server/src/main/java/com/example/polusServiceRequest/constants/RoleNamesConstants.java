package com.example.polusServiceRequest.constants;

public class RoleNamesConstants {
	public static final String DEFAULT_ROLE = "PRINCIPAL_INVESTIGATOR";
	public static final Long APPLICATION_ADMINISTRATOR=1L;
	public static final Long PRINCIPAL_INVESTIGATOR=2L;
}
