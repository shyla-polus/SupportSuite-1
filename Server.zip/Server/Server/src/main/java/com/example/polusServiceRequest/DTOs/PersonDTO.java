package com.example.polusServiceRequest.DTOs;

import java.util.List;

import lombok.Data;


public class PersonDTO {

	private Long personId;
	private String name;
	private List<RoleDTO> roles;
	public Long getPersonId() {
		return personId;
	}
	public void setPersonId(Long personId) {
		this.personId = personId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public List<RoleDTO> getRoles() {
		return roles;
	}
	public void setRoles(List<RoleDTO> roles) {
		this.roles = roles;
	}
	
	
}
