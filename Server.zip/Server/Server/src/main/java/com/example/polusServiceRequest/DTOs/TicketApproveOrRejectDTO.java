package com.example.polusServiceRequest.DTOs;

import lombok.Data;


public class TicketApproveOrRejectDTO {
	
	private Long ticketId;
	private String comment;
	private Long statusCode;
	public Long getTicketId() {
		return ticketId;
	}
	public void setTicketId(Long ticketId) {
		this.ticketId = ticketId;
	}
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	public Long getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(Long statusCode) {
		this.statusCode = statusCode;
	}
	
	

}
