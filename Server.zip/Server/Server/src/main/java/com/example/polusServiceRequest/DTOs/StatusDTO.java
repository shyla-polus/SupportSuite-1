package com.example.polusServiceRequest.DTOs;

import lombok.Data;


public class StatusDTO {
	private Long statusCode;
	private String status;
	
	public Long getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(Long statusCode) {
		this.statusCode = statusCode;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}

	
}
