package com.example.polusServiceRequest.DTOs;

import lombok.Data;


public class ServiceTicketsDetailsDTO {

	private Long personID;
	private Long statusType;
	private Long pageNumber;
	private Long pageSize;
	public Long getPersonID() {
		return personID;
	}
	public void setPersonID(Long personID) {
		this.personID = personID;
	}
	public Long getStatusType() {
		return statusType;
	}
	public void setStatusType(Long statusType) {
		this.statusType = statusType;
	}
	public Long getPageNumber() {
		return pageNumber;
	}
	public void setPageNumber(Long pageNumber) {
		this.pageNumber = pageNumber;
	}
	public Long getPageSize() {
		return pageSize;
	}
	public void setPageSize(Long pageSize) {
		this.pageSize = pageSize;
	}
	
	

}

