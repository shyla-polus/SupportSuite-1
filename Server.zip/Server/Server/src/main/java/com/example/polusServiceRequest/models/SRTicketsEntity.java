package com.example.polusServiceRequest.models;

import java.sql.Timestamp;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import lombok.Data;


@Entity
@Table(name = "SR_TICKETS")
public class SRTicketsEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "SR_TICKET_ID")
	private Long srTicketId;

	@ManyToOne
	@JoinColumn(name = "PERSON_ID")
	private PersonEntity person;

	@ManyToOne
	@JoinColumn(name = "CATEGORY_CODE")
	private SRTicketCategoryEntity category;

	@ManyToOne
	@JoinColumn(name = "ASSIGNED_TO")
	private PersonEntity assignedTo;

	@ManyToOne
	@JoinColumn(name = "STATUS_CODE")
	private SRTicketStatusEntity status;

	@Column(name = "DESCRIPTION")
	private String description;

	@Column(name = "CREATE_TIMESTAMP")
	private Timestamp createTimestamp;

	@Column(name = "UPDATE_TIMESTAMP")
	@Temporal(TemporalType.TIMESTAMP)
	private Timestamp updateTimestamp;
	
	 @OneToMany(mappedBy = "srTicket", cascade = CascadeType.ALL, orphanRemoval = true)
	    private List<SRTicketHistoryEntity> history;

	public Long getSrTicketId() {
		return srTicketId;
	}

	public void setSrTicketId(Long srTicketId) {
		this.srTicketId = srTicketId;
	}

	public PersonEntity getPerson() {
		return person;
	}

	public void setPerson(PersonEntity person) {
		this.person = person;
	}

	public SRTicketCategoryEntity getCategory() {
		return category;
	}

	public void setCategory(SRTicketCategoryEntity category) {
		this.category = category;
	}

	public PersonEntity getAssignedTo() {
		return assignedTo;
	}

	public void setAssignedTo(PersonEntity assignedTo) {
		this.assignedTo = assignedTo;
	}

	public SRTicketStatusEntity getStatus() {
		return status;
	}

	public void setStatus(SRTicketStatusEntity status) {
		this.status = status;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Timestamp getCreateTimestamp() {
		return createTimestamp;
	}

	public void setCreateTimestamp(Timestamp createTimestamp) {
		this.createTimestamp = createTimestamp;
	}

	public Timestamp getUpdateTimestamp() {
		return updateTimestamp;
	}

	public void setUpdateTimestamp(Timestamp updateTimestamp) {
		this.updateTimestamp = updateTimestamp;
	}

	public List<SRTicketHistoryEntity> getHistory() {
		return history;
	}

	public void setHistory(List<SRTicketHistoryEntity> history) {
		this.history = history;
	}

	 
	 
	
}