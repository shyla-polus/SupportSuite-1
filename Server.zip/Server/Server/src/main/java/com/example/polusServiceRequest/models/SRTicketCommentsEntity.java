package com.example.polusServiceRequest.models;

import java.sql.Timestamp;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Data;

@Entity
@Table(name = "SR_TICKET_COMMENTS")
public class SRTicketCommentsEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "COMMENT_ID")
    private Long commentId;

    @ManyToOne
    @JoinColumn(name = "SR_TICKET_ID", referencedColumnName = "SR_TICKET_ID")
    private SRTicketsEntity srTicket;

    @Column(name = "COMMENT", nullable = false)
    private String comment;

    @ManyToOne
    @JoinColumn(name = "COMMENT_USER")
    private PersonEntity commentUser;

    @Column(name = "COMMENT_TIMESTAMP", nullable = false)
    private Timestamp commentTimestamp;
    
    @ManyToOne
    @JoinColumn(name = "STATUS_TYPE", referencedColumnName = "STATUS_CODE")
    private SRTicketStatusEntity statusCode;
    
    

	public SRTicketStatusEntity getStatusType() {
		return statusCode;
	}

	public void setStatusType(SRTicketStatusEntity statusType) {
		this.statusCode = statusType;
	}

	public Long getCommentId() {
		return commentId;
	}

	public void setCommentId(Long commentId) {
		this.commentId = commentId;
	}

	public SRTicketsEntity getSrTicket() {
		return srTicket;
	}

	public void setSrTicket(SRTicketsEntity srTicket) {
		this.srTicket = srTicket;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public PersonEntity getCommentUser() {
		return commentUser;
	}

	public void setCommentUser(PersonEntity commentUser) {
		this.commentUser = commentUser;
	}

	public Timestamp getCommentTimestamp() {
		return commentTimestamp;
	}

	public void setCommentTimestamp(Timestamp commentTimestamp) {
		this.commentTimestamp = commentTimestamp;
	}
    
    
}
