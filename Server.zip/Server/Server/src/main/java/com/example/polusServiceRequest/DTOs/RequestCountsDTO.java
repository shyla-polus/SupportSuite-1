package com.example.polusServiceRequest.DTOs;

import lombok.Data;


public class RequestCountsDTO {

	private Long totalRequests;
	private Long inProgressRequests;
	private Long assignedRequests;
	private Long approvedRequests;
	private Long rejectedRequests;
	private Long assignedToMeRequests;
	private Long adminApproveRequests;
	private Long adminRejectRequests;
	public Long getTotalRequests() {
		return totalRequests;
	}
	public void setTotalRequests(Long totalRequests) {
		this.totalRequests = totalRequests;
	}
	public Long getInProgressRequests() {
		return inProgressRequests;
	}
	public void setInProgressRequests(Long inProgressRequests) {
		this.inProgressRequests = inProgressRequests;
	}
	public Long getAssignedRequests() {
		return assignedRequests;
	}
	public void setAssignedRequests(Long assignedRequests) {
		this.assignedRequests = assignedRequests;
	}
	public Long getApprovedRequests() {
		return approvedRequests;
	}
	public void setApprovedRequests(Long approvedRequests) {
		this.approvedRequests = approvedRequests;
	}
	public Long getRejectedRequests() {
		return rejectedRequests;
	}
	public void setRejectedRequests(Long rejectedRequests) {
		this.rejectedRequests = rejectedRequests;
	}
	public Long getAssignedToMeRequests() {
		return assignedToMeRequests;
	}
	public void setAssignedToMeRequests(Long assignedToMeRequests) {
		this.assignedToMeRequests = assignedToMeRequests;
	}
	public Long getAdminApproveRequests() {
		return adminApproveRequests;
	}
	public void setAdminApproveRequests(Long adminApproveRequests) {
		this.adminApproveRequests = adminApproveRequests;
	}
	public Long getAdminRejectRequests() {
		return adminRejectRequests;
	}
	public void setAdminRejectRequests(Long adminRejectRequests) {
		this.adminRejectRequests = adminRejectRequests;
	}
	
	
}
