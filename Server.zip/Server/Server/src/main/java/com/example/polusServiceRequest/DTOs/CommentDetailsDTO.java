package com.example.polusServiceRequest.DTOs;

import java.sql.Timestamp;

import lombok.Data;

public class CommentDetailsDTO {

	private Long commentId;
	private String Comment;
	private PersonDTO commentUser;
	private StatusDTO status;
	private Timestamp commentTimestamp;
	
	
	public StatusDTO getStatus() {
		return status;
	}
	public void setStatus(StatusDTO status) {
		this.status = status;
	}
	public Long getCommentId() {
		return commentId;
	}
	public void setCommentId(Long commentId) {
		this.commentId = commentId;
	}
	public String getComment() {
		return Comment;
	}
	public void setComment(String comment) {
		Comment = comment;
	}
	public PersonDTO getCommentUser() {
		return commentUser;
	}
	public void setCommentUser(PersonDTO commentUser) {
		this.commentUser = commentUser;
	}
	public Timestamp getCommentTimestamp() {
		return commentTimestamp;
	}
	public void setCommentTimestamp(Timestamp commentTimestamp) {
		this.commentTimestamp = commentTimestamp;
	}
	
	
}
